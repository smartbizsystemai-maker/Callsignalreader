package com.callsignal.reader.data

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.database.Cursor
import android.os.Build
import android.provider.CallLog
import android.telephony.SubscriptionInfo
import android.telephony.SubscriptionManager
import androidx.core.content.ContextCompat
import com.callsignal.reader.model.CallRecord
import com.callsignal.reader.model.CallType
import com.callsignal.reader.model.SimInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class CallLogRepository(private val context: Context) {

    private val dateTimeFormatter = SimpleDateFormat("MMM dd, yyyy · hh:mm a", Locale.getDefault())

    fun hasCallLogPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_CALL_LOG
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun hasPhoneStatePermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_PHONE_STATE
        ) == PackageManager.PERMISSION_GRANTED
    }

    suspend fun getCallLogs(limit: Int = 200): Result<List<CallRecord>> = withContext(Dispatchers.IO) {
        if (!hasCallLogPermission()) {
            return@withContext Result.failure(
                SecurityException("READ_CALL_LOG permission is not granted. User must enable access first.")
            )
        }

        val records = mutableListOf<CallRecord>()
        val simMap = loadActiveSubscriptions()

        val projection = arrayOf(
            CallLog.Calls._ID,
            CallLog.Calls.NUMBER,
            CallLog.Calls.CACHED_NAME,
            CallLog.Calls.DATE,
            CallLog.Calls.DURATION,
            CallLog.Calls.TYPE,
            CallLog.Calls.PHONE_ACCOUNT_ID
        )

        // Android CallLog providers do not accept SQL LIMIT in sortOrder.
        val sortOrder = "${CallLog.Calls.DATE} DESC"

        try {
            val cursor: Cursor? = context.contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                projection,
                null,
                null,
                sortOrder
            )

            cursor?.use { c ->
                val idIndex = c.getColumnIndex(CallLog.Calls._ID)
                val numberIndex = c.getColumnIndex(CallLog.Calls.NUMBER)
                val nameIndex = c.getColumnIndex(CallLog.Calls.CACHED_NAME)
                val dateIndex = c.getColumnIndex(CallLog.Calls.DATE)
                val durationIndex = c.getColumnIndex(CallLog.Calls.DURATION)
                val typeIndex = c.getColumnIndex(CallLog.Calls.TYPE)
                val accountIdIndex = c.getColumnIndex(CallLog.Calls.PHONE_ACCOUNT_ID)

                while (c.moveToNext() && records.size < limit) {
                    val id = if (idIndex != -1) c.getLong(idIndex) else 0L
                    val rawNumber = if (numberIndex != -1) c.getString(numberIndex) ?: "Private" else "Unknown"
                    val contactName = if (nameIndex != -1) c.getString(nameIndex) else null
                    val dateMillis = if (dateIndex != -1) c.getLong(dateIndex) else 0L
                    val durationSec = if (durationIndex != -1) c.getLong(durationIndex) else 0L
                    val rawType = if (typeIndex != -1) c.getInt(typeIndex) else -1
                    val rawAccountId = if (accountIdIndex != -1) c.getString(accountIdIndex) else null

                    val callType = mapCallType(rawType)
                    val simInfo = resolveSimInfo(rawAccountId, simMap)

                    records.add(
                        CallRecord(
                            id = id,
                            phoneNumber = rawNumber,
                            formattedNumber = formatPhoneNumber(rawNumber),
                            contactName = contactName?.takeIf { it.isNotBlank() },
                            timestampMillis = dateMillis,
                            formattedDateTime = formatTimestamp(dateMillis),
                            durationSeconds = durationSec,
                            formattedDuration = formatDuration(durationSec, callType),
                            callType = callType,
                            simInfo = simInfo
                        )
                    )
                }
            }
            Result.success(records)
        } catch (se: SecurityException) {
            Result.failure(se)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun loadActiveSubscriptions(): Map<String, SubscriptionInfo> {
        val map = mutableMapOf<String, SubscriptionInfo>()
        if (!hasPhoneStatePermission() || Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP_MR1) {
            return map
        }
        try {
            val subscriptionManager = context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as? SubscriptionManager
            val activeList = subscriptionManager?.activeSubscriptionInfoList
            activeList?.forEach { subInfo ->
                map[subInfo.subscriptionId.toString()] = subInfo
                subInfo.iccId?.let { map[it] = subInfo }
            }
        } catch (_: Throwable) {}
        return map
    }

    private fun resolveSimInfo(rawAccountId: String?, activeSubs: Map<String, SubscriptionInfo>): SimInfo {
        if (rawAccountId.isNullOrBlank()) {
            return SimInfo(null, null, null, null, null)
        }
        val matchedSub = activeSubs[rawAccountId]
        return if (matchedSub != null) {
            SimInfo(
                slotIndex = matchedSub.simSlotIndex,
                subscriptionId = matchedSub.subscriptionId,
                carrierName = matchedSub.carrierName?.toString(),
                displayName = matchedSub.displayName?.toString(),
                rawPhoneAccountId = rawAccountId
            )
        } else {
            val inferredSlot = when (rawAccountId.trim()) {
                "0" -> 0
                "1" -> 1
                else -> null
            }
            SimInfo(
                slotIndex = inferredSlot,
                subscriptionId = rawAccountId.toIntOrNull(),
                carrierName = null,
                displayName = if (inferredSlot != null) "SIM ${inferredSlot + 1}" else null,
                rawPhoneAccountId = rawAccountId
            )
        }
    }

    private fun mapCallType(type: Int): CallType = when (type) {
        CallLog.Calls.INCOMING_TYPE -> CallType.INCOMING
        CallLog.Calls.OUTGOING_TYPE -> CallType.OUTGOING
        CallLog.Calls.MISSED_TYPE -> CallType.MISSED
        CallLog.Calls.VOICEMAIL_TYPE -> CallType.VOICEMAIL
        CallLog.Calls.REJECTED_TYPE -> CallType.REJECTED
        CallLog.Calls.BLOCKED_TYPE -> CallType.BLOCKED
        else -> CallType.UNKNOWN
    }

    private fun formatTimestamp(millis: Long): String = try {
        dateTimeFormatter.format(Date(millis))
    } catch (_: Exception) {
        "Unknown date"
    }

    private fun formatDuration(seconds: Long, type: CallType): String {
        if (seconds <= 0) {
            return when (type) {
                CallType.MISSED -> "Missed"
                CallType.REJECTED -> "Rejected"
                CallType.BLOCKED -> "Blocked"
                else -> "0s"
            }
        }
        val hours = seconds / 3600
        val minutes = (seconds % 3600) / 60
        val remainingSeconds = seconds % 60
        return when {
            hours > 0 -> String.format(Locale.getDefault(), "%dh %02dm %02ds", hours, minutes, remainingSeconds)
            minutes > 0 -> String.format(Locale.getDefault(), "%dm %02ds", minutes, remainingSeconds)
            else -> "${remainingSeconds}s"
        }
    }

    private fun formatPhoneNumber(number: String): String {
        val cleaned = number.trim()
        if (cleaned.length == 10 && cleaned.all { it.isDigit() }) {
            return "(${cleaned.substring(0, 3)}) ${cleaned.substring(3, 6)}-${cleaned.substring(6)}"
        }
        if (cleaned.length == 11 && cleaned.startsWith("1") && cleaned.all { it.isDigit() }) {
            return "+1 (${cleaned.substring(1, 4)}) ${cleaned.substring(4, 7)}-${cleaned.substring(7)}"
        }
        return cleaned
    }
}