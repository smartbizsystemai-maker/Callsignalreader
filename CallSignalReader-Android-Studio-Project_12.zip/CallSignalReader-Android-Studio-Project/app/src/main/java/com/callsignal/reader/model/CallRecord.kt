package com.callsignal.reader.model

enum class CallType(val displayName: String) {
    INCOMING("Incoming"),
    OUTGOING("Outgoing"),
    MISSED("Missed"),
    REJECTED("Rejected"),
    BLOCKED("Blocked"),
    VOICEMAIL("Voicemail"),
    UNKNOWN("Unknown")
}

data class SimInfo(
    val slotIndex: Int?,
    val subscriptionId: Int?,
    val carrierName: String?,
    val displayName: String?,
    val rawPhoneAccountId: String?
) {
    val readableLabel: String
        get() = when {
            !displayName.isNullOrBlank() && slotIndex != null -> "SIM ${slotIndex + 1}: $displayName"
            !carrierName.isNullOrBlank() && slotIndex != null -> "SIM ${slotIndex + 1}: $carrierName"
            slotIndex != null -> "SIM ${slotIndex + 1}"
            !rawPhoneAccountId.isNullOrBlank() -> "Account ID: $rawPhoneAccountId"
            else -> "Default SIM"
        }
}

data class CallRecord(
    val id: Long,
    val phoneNumber: String,
    val formattedNumber: String,
    val contactName: String?,
    val timestampMillis: Long,
    val formattedDateTime: String,
    val durationSeconds: Long,
    val formattedDuration: String,
    val callType: CallType,
    val simInfo: SimInfo,
    val isRead: Boolean = true
) {
    private fun String.jsonEscaped(): String = buildString {
        this@jsonEscaped.forEach { ch ->
            when (ch) {
                '\\' -> append("\\\\")
                '"' -> append("\\\"")
                '\n' -> append("\\n")
                '\r' -> append("\\r")
                '\t' -> append("\\t")
                else -> if (ch.code < 0x20) append("\\u%04x".format(ch.code)) else append(ch)
            }
        }
    }

    private fun String?.jsonStringOrNull(): String =
        if (this == null) "null" else "\"" + this.jsonEscaped() + "\""

    fun toCrmStagedPayload(): String {
        val simSlot = simInfo.slotIndex?.plus(1)?.toString() ?: "null"
        val carrierJson = simInfo.carrierName.jsonStringOrNull()
        return """
            {
              "callsignal_record_id": "${id}",
              "phone_number": ${phoneNumber.jsonStringOrNull()},
              "contact_name": ${contactName.jsonStringOrNull()},
              "call_type": "${callType.name.lowercase()}",
              "timestamp_utc": "${java.time.Instant.ofEpochMilli(timestampMillis)}",
              "duration_seconds": ${durationSeconds},
              "sim_slot": ${simSlot},
              "carrier": ${carrierJson},
              "crm_sync_status": "ready_for_sync"
            }
        """.trimIndent()
    }
}
