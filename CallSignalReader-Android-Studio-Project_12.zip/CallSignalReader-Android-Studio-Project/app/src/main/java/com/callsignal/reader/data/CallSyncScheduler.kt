package com.callsignal.reader.data

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

object CallSyncScheduler {
    private const val PERIODIC_NAME = "callsignal-periodic-call-sync"
    private const val ONCE_NAME = "callsignal-immediate-call-sync"

    private fun constraints() = Constraints.Builder()
        .setRequiredNetworkType(NetworkType.CONNECTED)
        .build()

    fun schedule(context: Context) {
        val manager = WorkManager.getInstance(context.applicationContext)
        val periodic = PeriodicWorkRequestBuilder<CallSyncWorker>(15, TimeUnit.MINUTES)
            .setConstraints(constraints())
            .build()
        manager.enqueueUniquePeriodicWork(
            PERIODIC_NAME,
            ExistingPeriodicWorkPolicy.KEEP,
            periodic
        )
        requestImmediate(context)
    }

    fun requestImmediate(context: Context) {
        val request = OneTimeWorkRequestBuilder<CallSyncWorker>()
            .setConstraints(constraints())
            .build()
        WorkManager.getInstance(context.applicationContext).enqueueUniqueWork(
            ONCE_NAME,
            ExistingWorkPolicy.KEEP,
            request
        )
    }
}
