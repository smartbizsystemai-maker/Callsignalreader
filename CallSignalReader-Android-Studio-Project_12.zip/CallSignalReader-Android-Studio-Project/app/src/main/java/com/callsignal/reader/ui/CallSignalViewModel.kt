package com.callsignal.reader.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.callsignal.reader.data.CallLogRepository
import com.callsignal.reader.data.CallSyncRepository
import com.callsignal.reader.model.CallRecord
import com.callsignal.reader.model.CallType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class PermissionState {
    NOT_REQUESTED,
    GRANTED,
    DENIED,
    PERMANENTLY_DENIED
}

enum class CallFilter(val label: String) {
    ALL("All Calls"),
    INCOMING("Incoming"),
    OUTGOING("Outgoing"),
    MISSED("Missed")
}

data class CallSignalUiState(
    val permissionState: PermissionState = PermissionState.NOT_REQUESTED,
    val isLoading: Boolean = false,
    val callRecords: List<CallRecord> = emptyList(),
    val filteredRecords: List<CallRecord> = emptyList(),
    val errorMessage: String? = null,
    val selectedFilter: CallFilter = CallFilter.ALL,
    val searchQuery: String = "",
    val totalCount: Int = 0,
    val incomingCount: Int = 0,
    val outgoingCount: Int = 0,
    val missedCount: Int = 0,
    val lastRefreshedTimestamp: Long = 0L,
    val deviceToken: String = "",
    val syncMessage: String? = null,
    val isSyncing: Boolean = false
)

class CallSignalViewModel(
    private val repository: CallLogRepository,
    private val syncRepository: CallSyncRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(CallSignalUiState())
    val uiState: StateFlow<CallSignalUiState> = _uiState.asStateFlow()

    init {
        _uiState.update { it.copy(deviceToken = syncRepository.getToken()) }
        checkCurrentPermissionStatus()
    }

    fun checkCurrentPermissionStatus() {
        val hasPermission = repository.hasCallLogPermission()
        _uiState.update { current ->
            current.copy(
                permissionState = if (hasPermission) PermissionState.GRANTED else current.permissionState
            )
        }
        if (hasPermission) {
            refreshCallLogs()
        }
    }

    fun onPermissionResult(isGranted: Boolean, shouldShowRationale: Boolean) {
        if (isGranted) {
            _uiState.update {
                it.copy(
                    permissionState = PermissionState.GRANTED,
                    errorMessage = null
                )
            }
            refreshCallLogs()
        } else {
            val state = if (!shouldShowRationale) {
                PermissionState.PERMANENTLY_DENIED
            } else {
                PermissionState.DENIED
            }
            _uiState.update {
                it.copy(
                    permissionState = state,
                    errorMessage = if (state == PermissionState.PERMANENTLY_DENIED) {
                        "Call log permission is permanently blocked. Please grant permission in Android Settings > Apps > CallSignal Reader > Permissions."
                    } else {
                        "Access to call records was denied. Tap 'Enable Call Log Access' to grant permission."
                    }
                )
            }
        }
    }

    fun refreshCallLogs() {
        if (!repository.hasCallLogPermission()) {
            _uiState.update {
                it.copy(
                    permissionState = PermissionState.DENIED,
                    errorMessage = "Cannot refresh: READ_CALL_LOG permission not granted."
                )
            }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            val result = repository.getCallLogs(limit = 250)

            result.fold(
                onSuccess = { list ->
                    val inCount = list.count { it.callType == CallType.INCOMING }
                    val outCount = list.count { it.callType == CallType.OUTGOING }
                    val missCount = list.count { it.callType == CallType.MISSED || it.callType == CallType.REJECTED }

                    _uiState.update { current ->
                        val filtered = applyFilterAndSearch(list, current.selectedFilter, current.searchQuery)
                        current.copy(
                            isLoading = false,
                            callRecords = list,
                            filteredRecords = filtered,
                            totalCount = list.size,
                            incomingCount = inCount,
                            outgoingCount = outCount,
                            missedCount = missCount,
                            lastRefreshedTimestamp = System.currentTimeMillis(),
                            errorMessage = if (list.isEmpty()) "No call log entries found on this device." else null
                        )
                    }
                    if (syncRepository.getToken().isNotBlank() && list.isNotEmpty()) {
                        _uiState.update { it.copy(isSyncing = true, syncMessage = "Syncing calls to CRM…") }
                        val syncResult = syncRepository.sync(list)
                        syncResult.fold(
                            onSuccess = { sync -> _uiState.update { it.copy(isSyncing = false, syncMessage = sync.message) } },
                            onFailure = { ex -> _uiState.update { it.copy(isSyncing = false, syncMessage = ex.localizedMessage ?: "CRM sync failed") } }
                        )
                    } else {
                        _uiState.update { it.copy(syncMessage = "Enter device token below to sync calls to CRM.") }
                    }
                },
                onFailure = { ex ->
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            errorMessage = "Error reading call records: ${ex.localizedMessage ?: "Unknown Android error"}"
                        )
                    }
                }
            )
        }
    }


    fun updateDeviceToken(token: String) {
        _uiState.update { it.copy(deviceToken = token) }
    }

    fun saveDeviceToken() {
        syncRepository.saveToken(_uiState.value.deviceToken)
        _uiState.update { it.copy(syncMessage = if (_uiState.value.deviceToken.isBlank()) "Device token cleared." else "Device token saved on this phone. Tap Refresh to sync calls.") }
    }

    fun syncCallsNow() {
        val records = _uiState.value.callRecords
        viewModelScope.launch {
            _uiState.update { it.copy(isSyncing = true, syncMessage = "Syncing calls to CRM…") }
            syncRepository.sync(records).fold(
                onSuccess = { result -> _uiState.update { it.copy(isSyncing = false, syncMessage = result.message) } },
                onFailure = { ex -> _uiState.update { it.copy(isSyncing = false, syncMessage = ex.localizedMessage ?: "CRM sync failed") } }
            )
        }
    }

    fun setFilter(filter: CallFilter) {
        _uiState.update { current ->
            current.copy(
                selectedFilter = filter,
                filteredRecords = applyFilterAndSearch(current.callRecords, filter, current.searchQuery)
            )
        }
    }

    fun setSearchQuery(query: String) {
        _uiState.update { current ->
            current.copy(
                searchQuery = query,
                filteredRecords = applyFilterAndSearch(current.callRecords, current.selectedFilter, query)
            )
        }
    }

    fun clearErrorMessage() {
        _uiState.update { it.copy(errorMessage = null) }
    }

    private fun applyFilterAndSearch(records: List<CallRecord>, filter: CallFilter, query: String): List<CallRecord> {
        val filteredByType = when (filter) {
            CallFilter.ALL -> records
            CallFilter.INCOMING -> records.filter { it.callType == CallType.INCOMING }
            CallFilter.OUTGOING -> records.filter { it.callType == CallType.OUTGOING }
            CallFilter.MISSED -> records.filter {
                it.callType == CallType.MISSED || it.callType == CallType.REJECTED || it.callType == CallType.BLOCKED
            }
        }
        if (query.isBlank()) return filteredByType
        val normalized = query.trim().lowercase()
        return filteredByType.filter { record ->
            record.phoneNumber.contains(normalized) ||
                    (record.contactName?.lowercase()?.contains(normalized) == true) ||
                    (record.simInfo.displayName?.lowercase()?.contains(normalized) == true)
        }
    }
}