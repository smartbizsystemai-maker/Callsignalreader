package com.callsignal.reader

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.Color
import androidx.core.app.ActivityCompat
import com.callsignal.reader.data.CallLogRepository
import com.callsignal.reader.data.CallSyncRepository
import com.callsignal.reader.ui.CallSignalDashboard
import com.callsignal.reader.ui.CallSignalViewModel

class MainActivity : ComponentActivity() {
    private lateinit var viewModel: CallSignalViewModel
    private lateinit var repository: CallLogRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        repository = CallLogRepository(applicationContext)
        viewModel = CallSignalViewModel(repository, CallSyncRepository(applicationContext))

        setContent {
            CallSignalReaderTheme {
                val uiState by viewModel.uiState.collectAsState()
                val permissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestPermission()
                ) { isGranted ->
                    val shouldShowRationale = ActivityCompat.shouldShowRequestPermissionRationale(
                        this, Manifest.permission.READ_CALL_LOG
                    )
                    viewModel.onPermissionResult(isGranted, shouldShowRationale)
                }

                CallSignalDashboard(
                    uiState = uiState,
                    onEnableAccessClicked = {
                        permissionLauncher.launch(Manifest.permission.READ_CALL_LOG)
                    },
                    onRefreshClicked = { viewModel.refreshCallLogs() },
                    onFilterSelected = { filter -> viewModel.setFilter(filter) },
                    onSearchChanged = { query -> viewModel.setSearchQuery(query) },
                    onClearError = { viewModel.clearErrorMessage() },
                    onOpenSettings = { openAppSettings() },
                    onDeviceTokenChanged = { token -> viewModel.updateDeviceToken(token) },
                    onSaveDeviceToken = { viewModel.saveDeviceToken() },
                    onSyncNow = { viewModel.syncCallsNow() }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (::viewModel.isInitialized) viewModel.checkCurrentPermissionStatus()
    }

    private fun openAppSettings() {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", packageName, null)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        startActivity(intent)
    }
}

@Composable
private fun CallSignalReaderTheme(content: @Composable () -> Unit) {
    val colors = if (isSystemInDarkTheme()) {
        darkColorScheme(
            primary = Color(0xFF80CBC4),
            secondary = Color(0xFF80DEEA),
            background = Color(0xFF101820),
            surface = Color(0xFF18232D)
        )
    } else {
        lightColorScheme(
            primary = Color(0xFF00695C),
            secondary = Color(0xFF00838F),
            background = Color(0xFFF4F7F8),
            surface = Color.White
        )
    }
    MaterialTheme(colorScheme = colors, content = content)
}
