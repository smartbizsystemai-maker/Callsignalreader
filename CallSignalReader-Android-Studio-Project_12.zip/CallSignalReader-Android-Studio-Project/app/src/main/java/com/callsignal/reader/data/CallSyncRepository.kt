package com.callsignal.reader.data

import android.content.Context
import android.provider.Settings
import com.callsignal.reader.model.CallRecord
import com.callsignal.reader.model.CallType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class CallSyncRepository(context: Context) {
    private val prefs = context.getSharedPreferences("callsignal_sync", Context.MODE_PRIVATE)
    private val appContext = context.applicationContext

    companion object {
        const val ENDPOINT = "https://yxoenagcwcqzdfkncdwc.supabase.co/functions/v1/sync-call-logs"
    }

    fun getToken(): String = prefs.getString("device_token", "") ?: ""

    fun saveToken(token: String) {
        prefs.edit().putString("device_token", token.trim()).apply()
    }

    suspend fun sync(records: List<CallRecord>): Result<SyncResult> = withContext(Dispatchers.IO) {
        val token = getToken()
        if (token.isBlank()) return@withContext Result.failure(IllegalStateException("Enter your device token to enable CRM sync."))
        if (records.isEmpty()) return@withContext Result.success(SyncResult(0, 0, "No calls to sync."))

        val androidId = Settings.Secure.getString(appContext.contentResolver, Settings.Secure.ANDROID_ID) ?: "android-device"
        val calls = JSONArray()
        records.forEach { record ->
            val status = when (record.callType) {
                CallType.MISSED -> "missed"
                CallType.REJECTED, CallType.BLOCKED -> "rejected"
                CallType.INCOMING, CallType.OUTGOING -> if (record.durationSeconds > 0) "answered" else "cancelled"
                CallType.VOICEMAIL, CallType.UNKNOWN -> "cancelled"
            }
            val ingestionKey = "android:$androidId:${record.id}"
            val item = JSONObject()
                .put("ingestion_key", ingestionKey)
                .put("started_at", java.time.Instant.ofEpochMilli(record.timestampMillis).toString())
                .put("call_status", status)
                .put("duration_seconds", record.durationSeconds.coerceAtLeast(0))
                .put("caller_number", record.phoneNumber)
                .put("device_id", androidId)
                .put("sim_slot", record.simInfo.slotIndex?.plus(1) ?: JSONObject.NULL)
                .put("source_call_id", record.id.toString())
            calls.put(item)
        }

        var connection: HttpURLConnection? = null
        try {
            connection = (URL(ENDPOINT).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15000
                readTimeout = 20000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("x-device-token", token)
            }
            val payload = JSONObject().put("calls", calls).toString()
            connection.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val responseText = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            val response = try { JSONObject(responseText) } catch (_: Exception) { JSONObject() }
            if (code !in 200..299) {
                val message = response.optString("error", "HTTP $code")
                return@withContext Result.failure(IllegalStateException("CRM sync failed: $message"))
            }
            Result.success(
                SyncResult(
                    received = response.optInt("received", records.size),
                    saved = response.optInt("saved", 0),
                    message = if (response.optBoolean("ok", false)) "CRM sync complete. ${response.optInt("saved", 0)} saved; ${response.optInt("duplicates", 0)} duplicates." else response.optString("message", "Sync completed.")
                )
            )
        } catch (e: Exception) {
            Result.failure(IllegalStateException("CRM sync failed: ${e.localizedMessage ?: "Network error"}"))
        } finally {
            connection?.disconnect()
        }
    }
}

data class SyncResult(val received: Int, val saved: Int, val message: String)
