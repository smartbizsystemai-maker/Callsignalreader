package com.callsignal.reader.data

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.callsignal.reader.data.CallLogRepository
import com.callsignal.reader.data.CallSyncRepository

/** Reads the device call log and retries CRM sync when network becomes available.
 * The Android call log is the durable local source; ingestion keys make retries idempotent.
 */
class CallSyncWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val callRepository = CallLogRepository(applicationContext)
        if (!callRepository.hasCallLogPermission()) return Result.success()

        val syncRepository = CallSyncRepository(applicationContext)
        if (syncRepository.getToken().isBlank()) return Result.success()

        val recordsResult = callRepository.getCallLogs(limit = 250)
        val records = recordsResult.getOrElse { return Result.retry() }
        if (records.isEmpty()) return Result.success()

        val syncResult = syncRepository.sync(records)
        return if (syncResult.isSuccess) Result.success() else Result.retry()
    }
}
