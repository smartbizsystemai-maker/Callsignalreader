# CallSignal Reader (Native Android)

Native Android app built with Kotlin and Jetpack Compose to read device call logs with explicit user permission and prepare records for CallSignal CRM.

## 📱 Testing on a Real Android Phone

1. Enable Developer Options: Tap Build Number 7 times in Settings > About Phone.
2. Turn on USB Debugging in Developer Options.
3. Open in Android Studio Ladybug or build via command line:
   ```bash
   ./gradlew assembleDebug
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   ```


## Supabase CRM sync

This build sends the latest call-log records to the deployed `sync-call-logs` Edge Function when a device token is saved and the user taps **Sync Calls**. The app also attempts sync after refreshing call logs when a token is saved.

Endpoint: `https://yxoenagcwcqzdfkncdwc.supabase.co/functions/v1/sync-call-logs`

In the app, paste the current `CALLSIGNAL_DEVICE_TOKEN` secret into **CRM Sync → Supabase device token**, tap **Save Token**, then **Sync Calls**. Do not commit the token into source code. Note: a token stored on a device can be extracted from a compromised device; use per-device auth before production use.
