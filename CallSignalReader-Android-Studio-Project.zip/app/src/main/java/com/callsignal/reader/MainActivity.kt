package com.callsignal.reader

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.Color
import androidx.core.app.ActivityCompat
import com.callsignal.reader.data.CallLogRepository
import com.callsignal.reader.ui.CallSignalDashboard
import com.callsignal.reader.ui.CallSignalViewModel

class MainActivity : ComponentActivity() {

    private lateinit var viewModel: CallSignalViewModel
    private lateinit var repository: CallLogRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        repository = CallLogRepository(applicationContext)
        viewModel = CallSignalViewModel(repository)

        setContent {
            CallSignalReaderTheme {
                val uiState by viewModel.uiState.collectAsState()

                // Register runtime permission launcher for READ_CALL_LOG
                val permissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestPermission()
                ) { isGranted ->
                    val shouldShowRationale = ActivityCompat.shouldShowRequestPermissionRationale(
                        this,
                        Manifest.permission.READ_CALL_LOG
                    )
                    viewModel.onPermissionResult(isGranted, shouldShowRationale)
                }

                CallSignalDashboard(
                    uiState = uiState,
                    onEnableAccessClicked = {
                        // Request explicit permission ONLY on user action as mandated
                        permissionLauncher.launch(Manifest.permission.READ_CALL_LOG)
                    },
                    onRefreshClicked = {
                        viewModel.refreshCallLogs()
                    },
                    onFilterSelected = { filter ->
                        viewModel.setFilter(filter)
                    },
                    onSearchChanged = { query ->
                        viewModel.setSearchQuery(query)
                    },
                    onClearError = {
                        viewModel.clearErrorMessage()
                    },
                    onOpenSettings = {
                        openAppSettings()
                    }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (::viewModel.isInitialized) {
            viewModel.checkCurrentPermissionStatus()
        }
    }

    private fun openAppSettings() {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", packageName, null)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        startActivity(intent)
    }
}