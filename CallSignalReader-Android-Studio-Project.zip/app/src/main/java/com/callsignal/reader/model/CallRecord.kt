package com.callsignal.reader.model

enum class CallType(val displayName: String) {
    INCOMING("Incoming"),
    OUTGOING("Outgoing"),
    MISSED("Missed"),
    REJECTED("Rejected"),
    BLOCKED("Blocked"),
    VOICEMAIL("Voicemail"),
    UNKNOWN("Unknown")
}

data class SimInfo(
    val slotIndex: Int?,
    val subscriptionId: Int?,
    val carrierName: String?,
    val displayName: String?,
    val rawPhoneAccountId: String?
) {
    val readableLabel: String
        get() = when {
            !displayName.isNullOrBlank() && slotIndex != null -> "SIM ${slotIndex + 1}: $displayName"
            !carrierName.isNullOrBlank() && slotIndex != null -> "SIM ${slotIndex + 1}: $carrierName"
            slotIndex != null -> "SIM ${slotIndex + 1}"
            !rawPhoneAccountId.isNullOrBlank() -> "Account ID: $rawPhoneAccountId"
            else -> "Default SIM"
        }
}

data class CallRecord(
    val id: Long,
    val phoneNumber: String,
    val formattedNumber: String,
    val contactName: String?,
    val timestampMillis: Long,
    val formattedDateTime: String,
    val durationSeconds: Long,
    val formattedDuration: String,
    val callType: CallType,
    val simInfo: SimInfo,
    val isRead: Boolean = true
) {
    fun toCrmStagedPayload(): String {
        val safeName = contactName?.replace(""", "\"") ?: "null"
        return """
        {
          "callsignal_record_id": "$id",
          "phone_number": "$phoneNumber",
          "contact_name": ${if (contactName != null) "\"$safeName\"" else "null"},
          "call_type": "${callType.name.lowercase()}",
          "timestamp_utc": "${java.time.Instant.ofEpochMilli(timestampMillis)}",
          "duration_seconds": $durationSeconds,
          "sim_slot": ${simInfo.slotIndex?.plus(1) ?: "null"},
          "carrier": ${if (simInfo.carrierName != null) "\"${simInfo.carrierName}\"" else "null"},
          "crm_sync_status": "ready_for_sync"
        }
        """.trimIndent()
    }
}