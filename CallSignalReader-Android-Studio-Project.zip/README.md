# CallSignal Reader (Native Android)

Native Android app built with Kotlin and Jetpack Compose to read device call logs with explicit user permission and prepare records for CallSignal CRM.

## 📱 Testing on a Real Android Phone

1. Enable Developer Options: Tap Build Number 7 times in Settings > About Phone.
2. Turn on USB Debugging in Developer Options.
3. Open in Android Studio Ladybug or build via command line:
   ```bash
   ./gradlew assembleDebug
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   ```
